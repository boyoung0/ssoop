#include <iostream>
#include <string>

// 32page 
int main()
{
	char s[] = "hello";


	std::string s1 = "abcd";
	std::string s2 = "efg";

	std::string s3;
}