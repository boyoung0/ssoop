﻿// 1_레퍼런스3. 
struct Rect
{
	int x;
	int y;
	int width;
	int height;
};

void foo(Rect rc) { }

int main()
{
	Rect rc = { 10, 10, 100, 100 };

	foo(rc);
}
