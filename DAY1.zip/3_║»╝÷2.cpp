﻿#include <iostream>

// 26page - 중요한 변화.!

struct Point
{
	int x, y;
};
int main()
{
	
	int n = 10;
	int x[3] = { 1,2,3 };
	Point p1 = { 1,2 };
}



