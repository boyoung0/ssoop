﻿// 42 page
// 4_함수5. 후위 반환 타입

int square(int a)
{
	return a * a;
}
int main()
{
	square(3);
}
