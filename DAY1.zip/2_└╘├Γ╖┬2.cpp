﻿// 3_입출력2.cpp - 15 page아래 부분
#include <iostream>

int main()
{
	int n = 10;
	std::cout << n << std::endl; // 
	std::cout << n << std::endl; // 
	std::cout << n << std::endl; // 
	std::cout << n << std::endl; // 
}
