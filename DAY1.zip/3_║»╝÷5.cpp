﻿// 30 page

typedef int DWORD;
typedef void(*PF)();

int main()
{
	DWORD n; 
	PF    f; 
}

