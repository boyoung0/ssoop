﻿#include <iostream>

void foo(int* p) { std::cout << "int*" << std::endl;}
void foo(int n)  { std::cout << "int" << std::endl; }

int main()
{
	foo(0);
	foo(0);
}
