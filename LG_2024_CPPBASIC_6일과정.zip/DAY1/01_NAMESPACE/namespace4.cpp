﻿// 10 page

#include <stdio.h> 

int main()
{
	printf("hello\n"); // ok
	std::printf("hello\n"); // ??
}
