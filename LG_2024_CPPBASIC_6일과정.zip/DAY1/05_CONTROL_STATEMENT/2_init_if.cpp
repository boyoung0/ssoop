// init control statement
// 45page

int foo() { return 10;}

int main()
{
	int ret = foo();

	if ( ret == 10 )
	{

	}
}