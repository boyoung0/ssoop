// 59 page
int main()
{
	int n = 0;

	int* p1 = &n;
	int& r1 = n;
	
}