// 20 page
#include <iostream>
#include <print>

int main()
{	
	// C++98 style
	std::cout << "hello" << std::endl;


	int n = 1;
	double d = 3.1;
}