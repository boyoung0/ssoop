// OOP2 복사
