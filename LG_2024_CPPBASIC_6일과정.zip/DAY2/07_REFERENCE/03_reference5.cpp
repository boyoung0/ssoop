struct Rect
{
	int left;
	int top;
	int right;
	int bottom;
};

int foo(Rect rc) 
{ 
	
} 

int main()
{
	Rect rc = {1, 1, 10, 10};
	foo(rc);
}
