#include <iostream>

int main()
{
	// 사용자에게 5개의 정수를 입력 받고 싶다. 
	
}