#include <iostream>

int main()
{
	int cnt = 0;
	std::cout << "학생수를 입력하세요 >> ";
	std::cin >> cnt;

	// 입력된 학생수 만큼, 다시 점수를 입력 받아야 한다.
	int score[cnt]; // ?
	
}