#include <string>

// 사원을 관리하는데, 생일정보도 관리하고 싶다.
class Person
{
	std::string name;
	int age;
	int year;
	int month;
	int day;
};

int main()
{

}