#include <iostream>

class Date
{

};

int main()
{
	Date d1{2024, 3, 12};

}













// int days[12] = { 31, 28, 31, 30, 31, 30,  31, 31, 30, 31,30,31};
