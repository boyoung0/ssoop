#include <iostream>
#include <vector>

// 145page ~
// 파워 포인트 같은 프로그램을 만드는 것을 생각해 봅시다.


int main()
{
}



