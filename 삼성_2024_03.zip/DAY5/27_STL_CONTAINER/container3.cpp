#include <iostream>
#include <stack>
#include <queue>

int main()
{
	std::stack<int> s;
	std::queue<int> q;

	s.push(10);
	s.push(20);

	std::cout << s.top() << std::endl;
	std::cout << s.top() << std::endl;


	q.push(10);
	q.push(20);

	std::cout << q.top() << std::endl;
	std::cout << q.top() << std::endl;
}