#include <iostream>
#include <cstring>   

class vector
{
private:
	int* ptr;
	int  sz;

public:
	vector(int size, int value = 0 )
	{
		sz = size;
		ptr = new int[size];

		for( int i = 0; i < size; i++)
			ptr[i] = value;
	}
	~vector() { delete[] ptr; }
};

int main()
{
	vector v1{4, 1};
	vector v2 = v1;

}