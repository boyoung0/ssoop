class vector 
{
public:
	vector(int sz) {}
};

void foo(vector v) {}

int main()
{
	// 인자가 한개인 생성자가 있다면 아래처럼 4가지 형태로 객체 생성이 가능합니다.
	vector v1(10);
	vector v2 = 10;
	vector v3{10};
	vector v4 = {10};

	foo(10);
}