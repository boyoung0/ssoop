#include <vector>
#include <string>

void foo(std::string s) {}
void goo(std::vector<int> v) {}

int main()
{
	foo("hello");
	std::string s1("hello");
	std::string s2 = "hello";

	goo(10);
	std::vector<int> v1(10);
	std::vector<int> v2 = 10;
}