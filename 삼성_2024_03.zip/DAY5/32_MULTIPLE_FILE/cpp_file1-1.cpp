#include <iostream>

class Point
{
	int x, y;
public:
	Point(int a, int b) : x{a}, y{b} {}
	~Point() {}
	
	void set(int a, int b)	
	{						
		x = a;				
		y = b;				
	}
};

int main()
{
	Point p1{1,2};
	p1.set(10, 20); 
}
