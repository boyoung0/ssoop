#include <iostream>

int add(int a, int b)
{
	return a + b;
}

int main()
{
	int n = add(1,2);
	
	std::cout << n << std::endl;
}